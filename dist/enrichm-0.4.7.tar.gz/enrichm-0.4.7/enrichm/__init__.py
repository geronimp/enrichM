""" enrichm/__init__.py """

from .version import __version__
